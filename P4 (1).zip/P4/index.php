<?php
require_once ("Controllers/MonExpace.php");
$Espace = new Espace();
$Espace->Espacecontrole();