<?php
class PageAcceuil
{
    public function __construct()
    {
        require_once("Vieus/EspaceJeux2.php");
    }
}